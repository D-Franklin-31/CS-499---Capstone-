package com.example.franklininventoryapp;

public class InventoryItem {
    public int id;
    public String name;
    public int quantity;
    public String date;

    // Constructor to initialize a new inventory item
    public InventoryItem(int id, String name, int quantity, String date) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.date = date;
    }
}