package com.example.franklininventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    Database db;
    EditText nameField, quantityField, dateField;
    Button saveBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initialize database helper
        db = new Database(this);

        // Link UI fields
        nameField = findViewById(R.id.editTextName);
        quantityField = findViewById(R.id.editTextQuantity);
        dateField = findViewById(R.id.editTextDate);
        saveBtn = findViewById(R.id.buttonSaveItem);

        // Save button adds inventory item to the database
        saveBtn.setOnClickListener(v -> {
            String name = nameField.getText().toString();
            String qtyStr = quantityField.getText().toString();
            String date = dateField.getText().toString();

            // Validate input fields
            if (name.isEmpty() || qtyStr.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Convert quantity and save to DB
            int quantity = Integer.parseInt(qtyStr);
            boolean success = db.insertInventoryItem(name, quantity, date);

            // Notify user and return to inventory screen
            if (success) {
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, DataDisplayActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        });
    }
}