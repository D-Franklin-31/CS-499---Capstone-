package com.example.franklininventoryapp;

import androidx.lifecycle.ViewModel;
import java.util.ArrayList;
import java.util.List;

public class InventoryViewModel extends ViewModel {

    private List<InventoryItem> inventoryList = new ArrayList<>();

    public List<InventoryItem> getInventoryList() {
        return inventoryList;
    }

    public void setInventoryList(List<InventoryItem> inventoryList) {
        this.inventoryList = inventoryList;
    }

    public void addItem(InventoryItem item) {
        inventoryList.add(item);
    }

    public void clear() {
        inventoryList.clear();
    }
}
