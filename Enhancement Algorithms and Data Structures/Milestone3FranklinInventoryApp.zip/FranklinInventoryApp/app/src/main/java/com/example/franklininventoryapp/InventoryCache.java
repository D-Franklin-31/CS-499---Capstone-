package com.example.franklininventoryapp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


//Enhancement Algorthims and Data Structures
//new InventoryCache class
//Aligns with Course Outcomes: 3, 4
public class InventoryCache {

    private static final Map<Integer, InventoryItem> inventoryMap = new HashMap<>();

    public static void clear() {
        inventoryMap.clear();
    }

    public static void addItem(InventoryItem item) {
        inventoryMap.put(item.id, item);
    }

    public static InventoryItem getItem(int id) {
        return inventoryMap.get(id);
    }

    public static List<InventoryItem> getAllItems() {
        return new ArrayList<>(inventoryMap.values());
    }

    public static boolean contains(int id) {
        return inventoryMap.containsKey(id);
    }
}
