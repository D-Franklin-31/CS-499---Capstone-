package com.example.franklininventoryapp;

import android.content.Context;
import android.widget.Toast;

//Enhancement Algorthims and Data Structures
//new IputValidator class
//Aligns with Course Outcomes: 3, 4
public class InputValidator {

    public static boolean isValidItemInput(Context context, String name, String quantityStr, String date) {
        // Validate name
        if (name == null || name.trim().isEmpty()) {
            Toast.makeText(context, "Item name cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Validate quantity is a positive number
        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
            if (quantity < 0) {
                Toast.makeText(context, "Quantity must be a positive number", Toast.LENGTH_SHORT).show();
                return false;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(context, "Quantity must be a valid number", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Validate date format: yyyy-MM-dd
        if (!date.matches("\\d{2}-\\d{2}-\\d{4}")) {
            Toast.makeText(context, "Date must be in MM-DD-YYYY format", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}