package com.example.franklininventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1001;

    private Database dbHelper;
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private ArrayList<InventoryItem> inventoryList;

    private InventoryCacheManager cacheManager;

    private boolean isNameSortAsc = true;
    private boolean isQuantitySortAsc = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dbHelper = new Database(this);
        recyclerView = findViewById(R.id.recyclerViewInventory);
        Button addButton = findViewById(R.id.buttonAddItem);
        Button smsButton = findViewById(R.id.buttonSendSms); // Button in layout for SMS
        Button reportButton = findViewById(R.id.buttonLowStockReport);
        Button addMultipleButton = findViewById(R.id.buttonAddMultiple);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        inventoryList = new ArrayList<>();
        loadInventoryData(); // Fill the list from DB

        //initialize cache manager after loading data
        cacheManager = new InventoryCacheManager(this);
        List<InventoryItem> lowStock = cacheManager.getLowStockItems(5);

        adapter = new InventoryAdapter(
                this,
                inventoryList,
                itemId -> {
                    dbHelper.deleteInventoryItem(itemId);
                    loadInventoryData();
                    adapter.updateData(inventoryList);
                },
                item -> {
                    Intent intent = new Intent(this, AddItemActivity.class);
                    intent.putExtra("itemId", item.id);
                    intent.putExtra("name", item.name);
                    intent.putExtra("quantity", item.quantity);
                    intent.putExtra("date", item.date);
                    startActivity(intent);
                }
        );

        recyclerView.setAdapter(adapter);

        //add click listener for report button
        reportButton.setOnClickListener(v -> showLowStockReport());

        adapter.updateData(inventoryList);

        //Enhancement Software Engineering and Design
        //Aligns with Course Outcomes: 3, 4
        //tap item to edit
        adapter.setOnItemClickListener(item -> {
            showEditQuantityDialog(item);
        });

        addButton.setOnClickListener(v -> {
            startActivity(new Intent(this, AddItemActivity.class));
        });

        addMultipleButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddMultipleItemsActivity.class);
            startActivityForResult(intent, 101); // 101 = requestCode
        });

        smsButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                sendLowInventorySms();
            }
        });
    }

    //Enhancement Algorithms and Data Structures
    // Load inventory data from DB and show it in the RecyclerView
    private void loadInventoryData() {
        inventoryList.clear();
        //clear old cache
        InventoryCache.clear();

        Cursor cursor = dbHelper.getAllInventoryItems();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));

                InventoryItem item = new InventoryItem(id, name, quantity, date);
                inventoryList.add(item);
                //add item to cache
                InventoryCache.addItem(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
    }

    //send SMS if any inventory items are low
    private void sendLowInventorySms() {
        StringBuilder message = new StringBuilder("Low Inventory Items:\n");

        //collect low stock items
        for (InventoryItem item : inventoryList) {
            if (item.quantity < 5) {
                message.append(item.name).append(" - Qty: ").append(item.quantity).append("\n");
            }
        }
        //notify no items
        if (message.toString().equals("Low Inventory Items:\n")) {
            Toast.makeText(this, "No low inventory items.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("1234567890", null, message.toString(), null, null); // Replace with real number for testing
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendLowInventorySms();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Enhancement Software Engineering and Design
    //Aligns with Course Outcomes: 3,4
    //edit quantity on item click
    private void showEditQuantityDialog(InventoryItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Quantity");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(item.quantity));
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            int newQuantity = Integer.parseInt(input.getText().toString());
            dbHelper.updateInventoryItem(item.id, item.name, newQuantity, item.date);

            //update item in local list
            for (InventoryItem i : inventoryList) {
                if (i.id == item.id) {
                    i.quantity = newQuantity;
                    break;
                }
            }

            adapter.updateData(inventoryList);
            Toast.makeText(this, "Quantity updated", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    //Enhancement Algorithms and Data Structures
    //Aligns with Course Outcomes: 3,4
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        //setup search functionality
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) searchItem.getActionView();

        searchView.setQueryHint("Search by name");

        //triggers filtering in adapter on text input
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.filter(newText);
                return true;
            }
        });

        return true;
    }


    //Enhancement Software Engineering and Design
    //Enhancement Algorthims and Data Structures
    //added clear all items and sort
    //Aligns with Course Outcomes: 3, 4
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.action_clear_all) {
            //confirmation to clear all items
            new AlertDialog.Builder(this)
                    .setTitle("Clear All Items")
                    .setMessage("Are you sure you want to delete all items?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        dbHelper.clearAllInventoryItems();
                        inventoryList.clear();
                        adapter.updateData(inventoryList);
                        Toast.makeText(this, "All items cleared", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", null)
                    .show();
            return true;

            //sort by name
        } else if (itemId == R.id.action_sort_name) {
            //toggle direction
            isNameSortAsc = !isNameSortAsc;
            inventoryList.sort((item1, item2) -> {
                return isNameSortAsc
                        ? item1.name.compareToIgnoreCase(item2.name)
                        : item2.name.compareToIgnoreCase(item1.name);
            });
            adapter.updateData(inventoryList);
            Toast.makeText(this, "Sorted by Name (" + (isNameSortAsc ? "A-Z" : "Z-A") + ")", Toast.LENGTH_SHORT).show();
            return true;

            //sort by quantity
        } else if (itemId == R.id.action_sort_quantity) {
            //toggle direction
            isQuantitySortAsc = !isQuantitySortAsc;
            inventoryList.sort((item1, item2) -> {
                return isQuantitySortAsc
                        ? Integer.compare(item1.quantity, item2.quantity)
                        : Integer.compare(item2.quantity, item1.quantity);
            });
            adapter.updateData(inventoryList);
            Toast.makeText(this, "Sorted by Quantity (" + (isQuantitySortAsc ? "Low-High" : "High-Low") + ")", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }




    //Enhancement Algorithms and Data Structures
    //Aligns with Course Outcomes: 3,4
    //low inventory report
    private void showLowStockReport() {
        List<InventoryItem> cachedItems = (List<InventoryItem>) InventoryCache.getAllItems();

        if (cachedItems.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Inventory Report")
                    .setMessage("No inventory items to report.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }

        StringBuilder report = new StringBuilder("Low Stock Items:\n\n");
        boolean hasLowStock = false;

        for (InventoryItem item : cachedItems) {
            if (item.quantity < 5) {
                hasLowStock = true;
                report.append("- ")
                        .append(item.name)
                        .append(" (Quantity: ")
                        .append(item.quantity)
                        .append(")\n");
            }
        }

        if (!hasLowStock) {
            report = new StringBuilder("All inventory levels are sufficient.");
        }

        new AlertDialog.Builder(this)
                .setTitle("Inventory Report")
                .setMessage(report.toString())
                .setPositiveButton("OK", null)
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 101 && resultCode == RESULT_OK) {
            //reload DB and cache
            loadInventoryData();
            //refresh list
            adapter.updateData(inventoryList);
        }
    }
}
