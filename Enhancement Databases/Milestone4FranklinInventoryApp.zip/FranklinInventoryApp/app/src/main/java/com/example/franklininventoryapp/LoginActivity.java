package com.example.franklininventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    Database db;
    EditText usernameField, passwordField;
    Button loginBtn, registerBtn, forgotPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Make sure your layout name matches

        db = new Database(this);
        usernameField = findViewById(R.id.editTextUsername);
        passwordField = findViewById(R.id.editTextPassword);
        loginBtn = findViewById(R.id.buttonLogin);
        registerBtn = findViewById(R.id.buttonCreateAccount);
        forgotPassword = findViewById(R.id.forgotPasswordButton);

        // Login button
        loginBtn.setOnClickListener(v -> {
            String user = usernameField.getText().toString();
            String pass = passwordField.getText().toString();

            // Check against DB
            if (db.checkUser(user, pass)) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, DataDisplayActivity.class)); // Replace with your actual next screen
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        //Enhancement Databases
        //Aligns with Course Outcomes: 3, 4
        // Register button
        registerBtn.setOnClickListener(v -> {
            String user = usernameField.getText().toString().trim();
            String pass = passwordField.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Username and password cannot be empty.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.userExists(user)) {
                Toast.makeText(this, "Username already exists. Please choose another.", Toast.LENGTH_SHORT).show();
            } else {
                boolean success = db.insertUser(user, pass);
                if (success) {
                    Toast.makeText(this, "Account created successfully! Please log in.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Error creating account. Try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Enhancement Software Engineering and Design
        //Aligns with Course Outcomes: 4, 5
        //improves usability with a password recovery
        // Forgot Password button
        forgotPassword.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Password Recovery");

            final EditText input = new EditText(this);
            input.setHint("Enter your email address");
            input.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
            builder.setView(input);

            builder.setPositiveButton("Recover", (dialog, which) -> {
                String email = input.getText().toString().trim();

                if (!email.isEmpty() && email.contains("@")) {
                    //send recovery info
                    Toast.makeText(this, "Recovery link sent to " + email, Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Please enter a valid email.", Toast.LENGTH_SHORT).show();
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();
        });
    }
}