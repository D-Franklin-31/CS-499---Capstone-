package com.example.franklininventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

//Enhancement Algorthims and Data Structures
//new InventoryAdapter class
//Aligns with Course Outcomes: 3, 4


//adapter class to bind inventory data to RecyclerView rows
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private Context context;
    private ArrayList<InventoryItem> itemList;
    private ArrayList<InventoryItem> fullList;

    //listener interface for delete button action
    private OnDeleteClickListener deleteClickListener;

    //listener interface for edit button action
    private OnEditClickListener editClickListener;

    //custom interface for delete functionality
    public interface OnDeleteClickListener {
        void onDeleteClick(int itemId);
    }

    //custom interface for edit functionality
    public interface OnEditClickListener {
        void onEditClick(InventoryItem item);
    }


    public InventoryAdapter(Context context, ArrayList<InventoryItem> itemList,
                            OnDeleteClickListener deleteClickListener,
                            OnEditClickListener editClickListener) {
        this.context = context;
        //filtered list
        this.itemList = new ArrayList<>(itemList);
        //backup full list
        this.fullList = new ArrayList<>(itemList);
        this.deleteClickListener = deleteClickListener;
        this.editClickListener = editClickListener;
    }

    // Create a new ViewHolder when needed
    @Override
    public InventoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflate the layout for a single row in the RecyclerView
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_item, parent, false);
        return new InventoryViewHolder(view);
    }

    //bind data to the views in the row
    @Override
    public void onBindViewHolder(InventoryViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);

        // Set text values from the data model
        holder.name.setText(item.name);
        holder.quantity.setText(String.valueOf(item.quantity));
        holder.date.setText(item.date);

        //Enhancement Software Engineering and Design
        //Aligns with Course Outcomes: 3, 4
        // Set click listener for delete button
        holder.deleteBtn.setOnClickListener(v -> deleteClickListener.onDeleteClick(item.id));

        //Enhancement Software Engineering and Design
        //Aligns with Course Outcomes: 3, 4
        // Set click listener for edit button
        holder.editBtn.setOnClickListener(v -> editClickListener.onEditClick(item));

        //Enhancement Software Engineering and Design
        //Aligns with Course Outcomes: 3, 4
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(itemList.get(position));
            }
        });
    }

    //return the total number of items
    @Override
    public int getItemCount() {
        return itemList.size();
    }

    //refresh the data in the RecyclerView
    public void updateData(ArrayList<InventoryItem> newList) {
        itemList.clear();
        fullList.clear();
        itemList.addAll(newList);
        fullList.addAll(newList);
        //notify adapter of data change
        notifyDataSetChanged();
    }

    //holds view references for a single row
    public static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView name, quantity, date;
        Button deleteBtn, editBtn;

        public InventoryViewHolder(View itemView) {
            super(itemView);

            //Get references to TextViews and Buttons in layout
            name = itemView.findViewById(R.id.textViewItemName);
            quantity = itemView.findViewById(R.id.textViewQuantity);
            date = itemView.findViewById(R.id.textViewDate);
            deleteBtn = itemView.findViewById(R.id.buttonDeleteItem);
            editBtn = itemView.findViewById(R.id.buttonEditItem);
        }
    }

    public interface OnItemClickListener {
        void onItemClick(InventoryItem item);
    }

    private OnItemClickListener listener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    //Enhancement Algorithms and Data Structures
    //Aligns with Course Outcomes: 3,4
    //filter items
    public void filter(String text) {
        itemList.clear();
        if (text == null || text.trim().isEmpty()) {
            //show all if search is empty
            itemList.addAll(fullList);
        } else {
            String lowerText = text.toLowerCase();
            for (InventoryItem item : fullList) {
                if (item.name.toLowerCase().contains(lowerText)) {
                    //item found
                    itemList.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }
}
