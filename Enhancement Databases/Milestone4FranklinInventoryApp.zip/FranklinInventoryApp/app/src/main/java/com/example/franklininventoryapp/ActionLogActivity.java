package com.example.franklininventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

//Enhancement Databases
//Aligns with Course Outcomes: 3, 4, 5
//action log class
public class ActionLogActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ActionLogAdapter adapter;
    private Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_action_log);

        recyclerView = findViewById(R.id.recyclerViewLogs);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = new Database(this);
        List<ActionLog> logs = db.getAllLogs();

        adapter = new ActionLogAdapter(logs);
        recyclerView.setAdapter(adapter);

        Button backBtn = findViewById(R.id.buttonBackToInventory);
        backBtn.setOnClickListener(v -> {
            Intent intent = new Intent(ActionLogActivity.this, DataDisplayActivity.class);
            startActivity(intent);
            finish();
        });

    }
}
