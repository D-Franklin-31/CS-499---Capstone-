package com.example.franklininventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

//Enhancement Databases
//Aligns with Course Outcomes: 3, 4, 5
//action log adapter class
public class ActionLogAdapter extends RecyclerView.Adapter<ActionLogAdapter.LogViewHolder> {
    private List<ActionLog> logList;

    public ActionLogAdapter(List<ActionLog> logList) {
        this.logList = logList;
    }

    @NonNull
    @Override
    public LogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_2, parent, false);
        return new LogViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LogViewHolder holder, int position) {
        ActionLog log = logList.get(position);
        holder.title.setText("Action: " + log.actionType + " (Item ID: " + log.itemId + ")");
        holder.subtitle.setText("Time: " + log.timestamp);
    }

    @Override
    public int getItemCount() {
        return logList.size();
    }

    static class LogViewHolder extends RecyclerView.ViewHolder {
        TextView title, subtitle;

        LogViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(android.R.id.text1);
            subtitle = itemView.findViewById(android.R.id.text2);
        }
    }
}
