package com.example.franklininventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import java.util.List;
import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "InventoryApp.db";
    public static final String USER_TABLE = "users";
    public static final String INVENTORY_TABLE = "inventory";

    public Database(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + USER_TABLE + " (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)");
        //Enhancement Databases
        //Aligns with Course Outcomes: 3, 4
        //updated inventory table for the check for duplicates
        db.execSQL("CREATE TABLE " + INVENTORY_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "quantity INTEGER, " +
                "date TEXT, " +
                "UNIQUE(name, date))");
        //Enhancement Databases
        //Aligns with Course Outcomes: 3, 4, 5
        //table for actions
        db.execSQL("CREATE TABLE IF NOT EXISTS ActionLog (" +
                "log_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "item_id INTEGER, " +
                "action_type TEXT, " +
                "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY(item_id) REFERENCES inventory(id))"
        );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + INVENTORY_TABLE);
        db.execSQL("DROP TABLE IF EXISTS ActionLog");
        onCreate(db);
    }

    // Adds new user to users table
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("password", password);
        long result = db.insert(USER_TABLE, null, cv);
        return result != -1;
    }

    // Checks if user credentials exist in DB
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE + " WHERE username=? AND password=?", new String[]{username, password});
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    //Enhancement Databases
    //Aligns with Course Outcomes: 3, 4, 5
    //Check if a username already exists before creating new account
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE + " WHERE username=?", new String[]{username});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    //Enhancement Databases
    //Aligns with Course Outcomes: 3, 4
    //check for duplicate items
    public boolean itemExists(String name, String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + INVENTORY_TABLE + " WHERE name=? AND date=?",
                new String[]{name, date}
        );
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public long insertInventoryItem(String name, int quantity, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("quantity", quantity);
        values.put("date", date);

        long id = db.insert(INVENTORY_TABLE, null, values);
        return id;
    }


    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + INVENTORY_TABLE, null);
    }

    public boolean deleteInventoryItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(INVENTORY_TABLE, "id=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    public boolean updateInventoryItem(int id, String name, int quantity, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("quantity", quantity);
        values.put("date", date);
        int result = db.update(INVENTORY_TABLE, values, "id=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    //helper to clear all inventory items
    public void clearAllInventoryItems() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM inventory");
    }

    // Returns list instead of Cursor
    public List<InventoryItem> getAllInventoryItemsList() {
        List<InventoryItem> itemList = new ArrayList<>();
        Cursor cursor = getAllInventoryItems();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                itemList.add(new InventoryItem(id, name, quantity, date));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return itemList;
    }

    //Enhancement Databases
    //Aligns with Course Outcomes: 3, 4
    //insert method for actions
    public void insertLog(long itemId, String actionType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item_id", itemId);
        values.put("action_type", actionType);

        db.insert("ActionLog", null, values);
    }

    //Enhancement Databases
    //Aligns with Course Outcomes: 3, 4
    //method to fetch logs
    public List<ActionLog> getAllLogs() {
        List<ActionLog> logs = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM ActionLog ORDER BY timestamp DESC", null);

        if (cursor.moveToFirst()) {
            do {
                long logId = cursor.getLong(cursor.getColumnIndexOrThrow("log_id"));
                long itemId = cursor.getLong(cursor.getColumnIndexOrThrow("item_id"));
                String actionType = cursor.getString(cursor.getColumnIndexOrThrow("action_type"));
                String timestamp = cursor.getString(cursor.getColumnIndexOrThrow("timestamp"));

                logs.add(new ActionLog(logId, itemId, actionType, timestamp));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return logs;
    }

}