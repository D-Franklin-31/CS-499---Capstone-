package com.example.franklininventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    Database db;
    EditText nameField, quantityField, dateField;
    Button saveBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initialize database helper
        db = new Database(this);

        // Link UI fields
        nameField = findViewById(R.id.editTextName);
        quantityField = findViewById(R.id.editTextQuantity);
        dateField = findViewById(R.id.editTextDate);
        saveBtn = findViewById(R.id.buttonSaveItem);
        Button cancelBtn = findViewById(R.id.cancelBtn);

        //Enhancement
        cancelBtn.setOnClickListener(v -> {
            //go back to DataDisplayActivity without saving
            startActivity(new Intent(this, DataDisplayActivity.class));
            finish();
        });

        // Save button adds inventory item to the database
        saveBtn.setOnClickListener(v -> {
            String name = nameField.getText().toString().trim();
            String qtyStr = quantityField.getText().toString().trim();
            String date = dateField.getText().toString().trim();

            if (!InputValidator.isValidItemInput(this, name, qtyStr, date)) {
                return;
            }

            //Enhancement Databases
            //Aligns with course outcomes 3,4
            //check for duplicates
            if (db.itemExists(name, date)) {
                Toast.makeText(this, "Item already exists", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(qtyStr);
            long itemId = db.insertInventoryItem(name, quantity, date);

            if (itemId != -1) {
                db.insertLog(itemId, "Add");  //Log action
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, DataDisplayActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        });

    }
}