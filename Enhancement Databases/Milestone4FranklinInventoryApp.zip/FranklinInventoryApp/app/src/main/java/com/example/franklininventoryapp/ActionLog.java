package com.example.franklininventoryapp;
import androidx.recyclerview.widget.RecyclerView;

//Enhancement Databases
//Aligns with Course Outcomes: 3, 4, 5
//action log class
public class ActionLog {
    public long id;
    public long itemId;
    public String actionType;
    public String timestamp;

    public ActionLog(long id, long itemId, String actionType, String timestamp) {
        this.id = id;
        this.itemId = itemId;
        this.actionType = actionType;
        this.timestamp = timestamp;
    }
}
