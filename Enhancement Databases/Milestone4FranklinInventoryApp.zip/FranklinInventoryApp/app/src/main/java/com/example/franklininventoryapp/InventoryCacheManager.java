package com.example.franklininventoryapp;

import android.content.Context;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

//Enhancement Algorithms and Data Structure
//in-memory HashMap cache for O(1) item lookup and low stock report
//Aligns with Course Outcomes: 3, 4
public class InventoryCacheManager {

    private final HashMap<Integer, InventoryItem> inventoryMap = new HashMap<>();
    private final Database db;

    public InventoryCacheManager(Context context) {
        this.db = new Database(context);
        loadFromDatabase();
    }

    //load all items from the database into the in-memory cache
    public void loadFromDatabase() {
        inventoryMap.clear();
        List<InventoryItem> items = db.getAllInventoryItemsList(); // Custom method we’ll add
        for (InventoryItem item : items) {
            inventoryMap.put(item.id, item);
        }
    }

    //get item by ID in O(1) time
    public InventoryItem getItemById(int id) {
        return inventoryMap.get(id);
    }

    //Enhancement: Algorithms and Data Structures
    //Get list of items with quantity below threshold
    public List<InventoryItem> getLowStockItems(int threshold) {
        List<InventoryItem> lowStock = new ArrayList<>();
        for (InventoryItem item : inventoryMap.values()) {
            if (item.quantity < threshold) {
                lowStock.add(item);
            }
        }
        return lowStock;
    }

    public void updateItemInCache(InventoryItem updatedItem) {
        inventoryMap.put(updatedItem.id, updatedItem);
    }

    public void removeItemFromCache(int id) {
        inventoryMap.remove(id);
    }

    public void clearCache() {
        inventoryMap.clear();
    }
}
