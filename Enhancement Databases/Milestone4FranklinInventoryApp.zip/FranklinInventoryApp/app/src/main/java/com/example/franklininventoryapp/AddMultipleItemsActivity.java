package com.example.franklininventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

//Enhancement Algorthims and Data Structures
//new AddMultipleItemsActivity class
//Aligns with Course Outcomes: 3, 4

public class AddMultipleItemsActivity extends AppCompatActivity {

    private LinearLayout layoutItemContainer;
    private Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_multiple_items);

        layoutItemContainer = findViewById(R.id.layoutItemContainer);
        Button buttonAddRow = findViewById(R.id.buttonAddRow);
        Button buttonSaveAll = findViewById(R.id.buttonSaveAll);
        Button cancelBtn = findViewById(R.id.cancelBtn);
        dbHelper = new Database(this);

        //Enhancement
        cancelBtn.setOnClickListener(v -> {
            // Go back to DataDisplayActivity without saving
            startActivity(new Intent(this, DataDisplayActivity.class));
            finish();
        });

        // Add the first row by default
        addNewRow();

        buttonAddRow.setOnClickListener(v -> addNewRow());

        buttonSaveAll.setOnClickListener(v -> saveAllItems());
    }

    private void addNewRow() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View rowView = inflater.inflate(R.layout.item_input_row, null);
        layoutItemContainer.addView(rowView, layoutItemContainer.getChildCount() - 2); // before buttons
    }

    private void saveAllItems() {
        int savedCount = 0;

        for (int i = 0; i < layoutItemContainer.getChildCount(); i++) {
            View row = layoutItemContainer.getChildAt(i);
            EditText nameInput = row.findViewById(R.id.editTextItemName);
            EditText quantityInput = row.findViewById(R.id.editTextItemQuantity);
            EditText dateInput = row.findViewById(R.id.editTextItemDate);

            if (nameInput != null && quantityInput != null && dateInput != null) {
                String name = nameInput.getText().toString().trim();
                String quantityStr = quantityInput.getText().toString().trim();
                String date = dateInput.getText().toString().trim();

                if (InputValidator.isValidItemInput(this, name, quantityStr, date)) {
                    int quantity = Integer.parseInt(quantityStr);
                    dbHelper.insertInventoryItem(name, quantity, date);
                    savedCount++;
                }
            }
        }

        Toast.makeText(this, savedCount + " items saved", Toast.LENGTH_SHORT).show();

        if (savedCount > 0) {
            setResult(RESULT_OK);
            finish();
        }
    }
}