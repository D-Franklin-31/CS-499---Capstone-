package com.example.franklininventoryapp;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsHelper {
    public static final int SMS_PERMISSION_CODE = 1001;

    public static boolean hasSmsPermission(Activity activity) {
        return ContextCompat.checkSelfPermission(activity, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    public static void requestSmsPermission(Activity activity) {
        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    // Sends SMS if permission granted
    public static void sendSms(String phoneNumber, String message, Activity activity) {
        if (hasSmsPermission(activity)) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(activity, "SMS sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(activity, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
            // Request SMS permission if not yet granted
        } else {
            requestSmsPermission(activity);
        }
    }
}